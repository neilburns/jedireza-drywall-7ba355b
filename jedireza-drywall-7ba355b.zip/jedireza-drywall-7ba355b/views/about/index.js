'use strict';

exports.init = function(req, res){
  res.render('about/index');
};
